<script src="unpkg.com/swiper%407.4.1/swiper-bundle.min.js"></script>
<script src="ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="js/app.js"></script>